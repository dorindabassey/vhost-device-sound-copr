# Changelog
## Unreleased

### Added

### Changed

### Fixed

### Deprecated

## v0.1.0

First release with null, pipewire and alsa host audio backends.
